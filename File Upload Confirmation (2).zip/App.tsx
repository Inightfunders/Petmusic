import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import WhyPetsNeedMusic from './components/WhyPetsNeedMusic';
import Personalized from './components/Personalized';
import Soundscapes from './components/Soundscapes';
import Subscription from './components/Subscription';
import DemoVideo from './components/DemoVideo';
import Footer from './components/Footer';
import PetQuestionnaire from './components/PetQuestionnaire';
import EmailDeliverySubscription from './components/EmailDeliverySubscription';
import PaymentSuccessPage from './components/PaymentSuccessPage';
import useAnimations from './hooks/useAnimations';
import './index.css';

function App() {
  // Initialize animations
  useAnimations();
  
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <WhyPetsNeedMusic />
              <Personalized />
              <Soundscapes />
              <Subscription />
              <DemoVideo />
            </>
          } />
          <Route path="/questionnaire" element={<PetQuestionnaire />} />
          <Route path="/email-delivery" element={<EmailDeliverySubscription />} />
          <Route path="/payment-success" element={<PaymentSuccessPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
