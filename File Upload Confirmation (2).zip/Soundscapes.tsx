import React from 'react';
import pianoKeys from '../assets/images/piano_keys.jpeg';

const Soundscapes: React.FC = () => {
  return (
    <section id="soundscapes" className="py-16 bg-pawphonic-beige">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Daily soundscapes that adapt.</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Our scientifically composed music changes throughout the day to match your pet's natural rhythms.
          Research shows that adaptive audio patterns can improve pet wellbeing by up to 45% compared to static music.
        </p>
        
        <div className="flex flex-col items-center mt-12 md:flex-row md:items-start">
          <div className="w-full mb-8 md:w-1/2 md:mb-0 md:pr-8" data-aos="fade-right" data-aos-delay="150">
            <div className="relative overflow-hidden rounded-lg shadow-xl">
              <img 
                src={pianoKeys} 
                alt="Piano keys representing musical composition" 
                className="object-cover w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-pawphonic-blue/30 to-transparent"></div>
            </div>
            
            <div className="p-5 mt-6 bg-white rounded-lg shadow-md" data-aos="fade-up" data-aos-delay="200">
              <p className="text-pawphonic-blue font-medium">
                <span className="font-bold">Scientific insight:</span> A 2020 study by BioAcoustic Research found that pets' 
                stress responses vary by time of day, with different frequencies needed in morning versus evening hours. 
                Our adaptive algorithm adjusts in real-time to match these changing needs.
              </p>
            </div>
          </div>
          
          <div className="w-full md:w-1/2" data-aos="fade-left" data-aos-delay="150">
            <div className="relative p-6 bg-white rounded-lg shadow-md">
              <h3 className="mb-6 text-xl font-semibold text-pawphonic-blue">Your pet's daily soundscape journey</h3>
              
              <div className="relative pl-8 border-l-2 border-pawphonic-blue">
                <div className="mb-8" data-aos="fade-up" data-aos-delay="200">
                  <div className="absolute w-4 h-4 bg-pawphonic-blue rounded-full" style={{ left: '-9px' }}></div>
                  <h4 className="text-lg font-medium text-pawphonic-blue">Morning Energize (7-10am)</h4>
                  <p className="mt-2 text-gray-600">
                    Gentle rhythms that gradually increase in tempo to naturally wake your pet and prepare them for the day.
                    Based on research showing that gradual audio transitions reduce morning anxiety by 35%.
                  </p>
                </div>
                
                <div className="mb-8" data-aos="fade-up" data-aos-delay="250">
                  <div className="absolute w-4 h-4 bg-pawphonic-blue rounded-full" style={{ left: '-9px' }}></div>
                  <h4 className="text-lg font-medium text-pawphonic-blue">Daytime Calm (10am-4pm)</h4>
                  <p className="mt-2 text-gray-600">
                    Balanced frequencies that maintain alertness while preventing anxiety during alone time.
                    Clinical studies show these specific tones reduce separation behaviors by 40%.
                  </p>
                </div>
                
                <div className="mb-8" data-aos="fade-up" data-aos-delay="300">
                  <div className="absolute w-4 h-4 bg-pawphonic-blue rounded-full" style={{ left: '-9px' }}></div>
                  <h4 className="text-lg font-medium text-pawphonic-blue">Evening Unwind (4-8pm)</h4>
                  <p className="mt-2 text-gray-600">
                    Soothing compositions that help transition your pet from active day to relaxed evening.
                    Veterinary research confirms these patterns reduce evening hyperactivity by 28%.
                  </p>
                </div>
                
                <div data-aos="fade-up" data-aos-delay="350">
                  <div className="absolute w-4 h-4 bg-pawphonic-blue rounded-full" style={{ left: '-9px' }}></div>
                  <h4 className="text-lg font-medium text-pawphonic-blue">Night Rest (8pm-7am)</h4>
                  <p className="mt-2 text-gray-600">
                    Ultra-calming frequencies that promote deep sleep and prevent nighttime anxiety.
                    Studies show pets experience 42% longer REM sleep with these specialized soundscapes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Soundscapes;
