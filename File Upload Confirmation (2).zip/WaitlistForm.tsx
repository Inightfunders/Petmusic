import React, { useState } from 'react';
import mailchimpService from '../services/mailchimp';

interface WaitlistFormProps {
  buttonText?: string;
  className?: string;
}

const WaitlistForm: React.FC<WaitlistFormProps> = ({ 
  buttonText = 'Join Waitlist',
  className = ''
}) => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setSubmitStatus('error');
      setErrorMessage('Please enter your email address');
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      // Call the Mailchimp service
      const response = await mailchimpService.subscribeToWaitlist(email);
      
      if (response.success) {
        setSubmitStatus('success');
        setEmail('');
      } else {
        setSubmitStatus('error');
        setErrorMessage(response.message || 'Something went wrong. Please try again.');
      }
    } catch (error) {
      setSubmitStatus('error');
      setErrorMessage('Failed to subscribe. Please try again later.');
      console.error('Subscription error:', error);
    } finally {
      setIsSubmitting(false);
      
      // Reset status after 5 seconds
      setTimeout(() => {
        if (submitStatus === 'success' || submitStatus === 'error') {
          setSubmitStatus('idle');
        }
      }, 5000);
    }
  };

  return (
    <div className={className}>
      <form onSubmit={handleSubmit} className="flex flex-col w-full space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pawphonic-blue focus:border-transparent"
        />
        <button 
          type="submit" 
          disabled={isSubmitting}
          className="btn-primary flex items-center justify-center"
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <svg className="w-5 h-5 mr-2 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </span>
          ) : buttonText}
        </button>
      </form>
      
      {submitStatus === 'success' && (
        <div className="mt-4 text-sm text-green-600">
          Thank you! You've been added to our waitlist.
        </div>
      )}
      
      {submitStatus === 'error' && (
        <div className="mt-4 text-sm text-red-600">
          {errorMessage}
        </div>
      )}
    </div>
  );
};

export default WaitlistForm;
