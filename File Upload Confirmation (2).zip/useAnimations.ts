import { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

/**
 * Hook to initialize and configure AOS (Animate On Scroll) library
 */
const useAnimations = () => {
  useEffect(() => {
    // Initialize AOS with enhanced configuration for smoother animations
    AOS.init({
      duration: 800,
      easing: 'ease-in-out-cubic', // Using a valid AOS easing option
      once: false,
      mirror: true,
      offset: 50,
      delay: 100, // Small delay for more polished sequential animations
      anchorPlacement: 'top-bottom', // Ensures animations trigger at the right scroll position
    });

    // Update AOS on window resize and scroll for better responsiveness
    const refreshAOS = () => {
      AOS.refresh();
    };

    window.addEventListener('resize', refreshAOS);
    window.addEventListener('scroll', refreshAOS, { passive: true });

    return () => {
      window.removeEventListener('resize', refreshAOS);
      window.removeEventListener('scroll', refreshAOS);
    };
  }, []);
};

export default useAnimations;
