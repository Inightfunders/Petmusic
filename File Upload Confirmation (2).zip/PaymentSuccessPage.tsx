import React from 'react';
import { Link } from 'react-router-dom';

const PaymentSuccessPage: React.FC = () => {
  return (
    <section className="py-16 bg-pawphonic-beige min-h-screen">
      <div className="container px-4 mx-auto">
        <div className="max-w-2xl mx-auto p-8 bg-white rounded-xl shadow-custom">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-pawphonic-green">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            
            <h2 className="text-3xl font-bold text-pawphonic-blue mb-4">Payment Successful!</h2>
            <p className="text-xl mb-6">Thank you for subscribing to Pawphonic.</p>
            
            <div className="p-6 bg-pawphonic-beige rounded-lg mb-8">
              <h3 className="text-xl font-semibold text-pawphonic-blue mb-3">Next Steps:</h3>
              <ol className="text-left space-y-3 ml-6 list-decimal">
                <li>Complete the pet questionnaire to help us create personalized music for your pet</li>
                <li>Set up your email delivery preferences</li>
                <li>Within 3 weeks, you'll receive your first personalized music tracks via email</li>
              </ol>
            </div>
            
            <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4 justify-center">
              <Link 
                to="/questionnaire"
                className="px-8 py-3 text-lg font-medium text-white transition-all rounded-lg bg-pawphonic-blue hover:bg-pawphonic-blue-dark"
              >
                Complete Pet Questionnaire
              </Link>
              
              <Link 
                to="/"
                className="px-8 py-3 text-lg font-medium transition-all border-2 rounded-lg text-pawphonic-blue border-pawphonic-blue hover:bg-pawphonic-blue hover:text-white"
              >
                Return to Homepage
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PaymentSuccessPage;
