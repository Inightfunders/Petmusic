import React from 'react';
import goldenRetrieverSpeaker from '../assets/images/golden_retriever_speaker.png';
import { enhancedTestimonials } from '../data/scientificData';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative py-20 overflow-hidden bg-pawphonic-beige">
      <div className="container relative z-10 px-4 mx-auto">
        <div className="flex flex-col items-center md:flex-row md:justify-between">
          <div className="w-full mb-10 text-center md:text-left md:w-1/2 md:pr-10 md:mb-0" data-aos="fade-right">
            <h1 className="mb-6 text-4xl font-bold leading-tight text-pawphonic-blue md:text-5xl lg:text-6xl">
              Music that comforts your pet—anytime you're away.
            </h1>
            
            <p className="mb-8 text-lg text-gray-700 md:text-xl">
              Scientifically designed playlists to reduce stress and loneliness for your dog or cat. 
              Personalized to your pet's mood, age, and energy level.
            </p>
            
            <p className="mb-8 text-md text-gray-600 bg-white p-4 rounded-lg shadow-sm border-l-4 border-pawphonic-blue">
              <strong>Proven by science:</strong> Studies show that specially composed music can reduce pet anxiety by up to 30%, lower cortisol levels, and improve sleep quality.
            </p>
            
            <div className="flex flex-col items-center space-y-4 md:flex-row md:space-y-0 md:space-x-4 md:items-start">
              <a 
                href="#waitlist" 
                className="px-8 py-3 text-lg font-medium text-white transition-all rounded-lg bg-pawphonic-blue hover:bg-pawphonic-blue-dark"
                data-aos="fade-up"
                data-aos-delay="200"
              >
                Join the Waitlist
              </a>
              
              <a 
                href="#demo" 
                className="px-8 py-3 text-lg font-medium transition-all border-2 rounded-lg text-pawphonic-blue border-pawphonic-blue hover:bg-pawphonic-blue hover:text-white"
                data-aos="fade-up"
                data-aos-delay="300"
              >
                See How It Works
              </a>
            </div>
          </div>
          
          <div className="w-full md:w-1/2" data-aos="fade-left">
            <div className="relative">
              <div className="absolute inset-0 transform translate-x-4 translate-y-4 bg-pawphonic-blue rounded-lg"></div>
              <img 
                src={goldenRetrieverSpeaker} 
                alt="Golden retriever sleeping peacefully next to a wooden speaker with music notes" 
                className="relative z-10 object-cover w-full rounded-lg shadow-xl"
              />
              
              <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-1/2 bg-white rounded-lg shadow-lg md:max-w-xs md:mx-auto" data-aos="fade-up" data-aos-delay="400">
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 text-white rounded-full bg-pawphonic-blue">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">From {enhancedTestimonials[0].name}</p>
                    <p className="text-sm font-bold text-gray-800">"{enhancedTestimonials[0].quote.substring(0, 70)}..."</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
