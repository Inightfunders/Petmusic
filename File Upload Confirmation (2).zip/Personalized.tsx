import React from 'react';
import { musicBenefits } from '../data/scientificData';
import dogAutumnForest from '../assets/images/dog_autumn_forest.jpeg';

const Personalized: React.FC = () => {
  return (
    <section id="personalized" className="py-16 bg-white">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Personalized just for your pet.</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Our scientifically designed algorithm creates custom playlists based on your pet's unique needs.
          Research shows that personalized audio reduces anxiety by up to 30% more than generic pet music.
        </p>
        
        <div className="flex flex-col items-center mt-12 md:flex-row md:items-start">
          <div className="w-full mb-8 md:w-1/2 md:mb-0 md:pr-8" data-aos="fade-right" data-aos-delay="150">
            <div className="p-6 bg-pawphonic-beige rounded-lg shadow-md" data-aos="fade-up" data-aos-delay="200">
              <h3 className="mb-4 text-xl font-semibold text-pawphonic-blue">Take the 2-minute quiz</h3>
              
              <div className="space-y-6">
                <div className="p-4 bg-white rounded-lg">
                  <h4 className="mb-2 font-medium">1. What type of pet do you have?</h4>
                  <div className="flex space-x-4">
                    <button className="px-4 py-2 text-white rounded-lg bg-pawphonic-blue">Dog</button>
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">Cat</button>
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">Both</button>
                  </div>
                </div>
                
                <div className="p-4 bg-white rounded-lg">
                  <h4 className="mb-2 font-medium">2. What's your pet's age?</h4>
                  <div className="flex space-x-4">
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">Puppy/Kitten</button>
                    <button className="px-4 py-2 text-white rounded-lg bg-pawphonic-blue">Adult</button>
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">Senior</button>
                  </div>
                </div>
                
                <div className="p-4 bg-white rounded-lg">
                  <h4 className="mb-2 font-medium">3. Does your pet experience anxiety when alone?</h4>
                  <div className="flex space-x-4">
                    <button className="px-4 py-2 text-white rounded-lg bg-pawphonic-blue">Yes</button>
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">Sometimes</button>
                    <button className="px-4 py-2 border rounded-lg border-pawphonic-blue text-pawphonic-blue">No</button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 text-center">
                <p className="mb-4 text-sm text-gray-600">
                  Based on a 2022 study, personalized audio frequencies matched to your pet's age, breed, and anxiety level 
                  can reduce stress hormones by up to 40% compared to generic calming music.
                </p>
                <button className="px-6 py-2 text-white rounded-lg bg-pawphonic-blue">
                  See More Questions
                </button>
              </div>
            </div>
          </div>
          
          <div className="w-full md:w-1/2" data-aos="fade-left" data-aos-delay="150">
            <div className="relative overflow-hidden rounded-lg shadow-xl">
              <img 
                src={dogAutumnForest} 
                alt="Dog relaxing in autumn forest" 
                className="object-cover w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-pawphonic-blue/30 to-transparent"></div>
            </div>
            
            <div className="mt-8 space-y-6">
              <div className="p-6 bg-white rounded-lg shadow-md" data-aos="fade-up" data-aos-delay="250">
                <h3 className="mb-3 text-xl font-semibold text-pawphonic-blue">Science-backed personalization</h3>
                <p className="text-gray-600">
                  Our algorithm analyzes 20+ factors about your pet to create the perfect audio experience. 
                  Research from the University of Glasgow (2017) shows that different pets respond to different 
                  musical elements based on their unique characteristics.
                </p>
              </div>
              
              <div className="p-6 bg-white rounded-lg shadow-md" data-aos="fade-up" data-aos-delay="300">
                <h3 className="mb-3 text-xl font-semibold text-pawphonic-blue">Adapts as your pet changes</h3>
                <p className="text-gray-600">
                  As your pet ages or their behavior changes, our system automatically adjusts their music therapy.
                  Studies show that a pet's audio preferences evolve throughout their life, requiring different 
                  frequencies and patterns at different stages.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Personalized;
