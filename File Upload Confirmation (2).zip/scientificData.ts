// Scientific data points about music effects on pets
export const scientificData = [
  {
    id: 1,
    year: 2002,
    researcher: "Dr. Deborah Wells",
    institution: "Animal Behaviorist",
    finding: "Dogs spent more time resting and being quiet, and less time standing when exposed to classical music compared to heavy metal music, pop music, or conversation.",
    source: "Animal Welfare Journal"
  },
  {
    id: 2,
    year: 2005,
    researcher: "Dr. Susan Wagner",
    institution: "Board-certified veterinary neurologist",
    finding: "Solo piano music created with slower tempos and simple arrangements was more effective in reducing anxiety than popular classic music. While both calmed dogs enough to make them lie down, the solo piano was even more effective.",
    source: "Through a Dog's Ear research"
  },
  {
    id: 3,
    year: 2012,
    researcher: "Dr. Lori Kogan",
    institution: "Colorado State College of Veterinary Medicine",
    finding: "In a study of 117 dogs in a kennel environment, dogs spent more time sleeping and less time vocalizing when listening to classical music compared to other music or no music.",
    source: "Journal of Veterinary Behavior"
  },
  {
    id: 4,
    year: 2017,
    researcher: "Scottish SPCA and University of Glasgow",
    institution: "University of Glasgow",
    finding: "Soft rock and reggae music led to more relaxed behaviors and increased heart rate variability in dogs, which indicates lower stress levels.",
    source: "Physiology & Behavior Journal"
  },
  {
    id: 5,
    year: 2020,
    researcher: "Joshua Leeds",
    institution: "BioAcoustic Research",
    finding: "About 10 percent of pets in the United States suffer from anxiety because they're living in human circumstances, which can be stressful. Music can help change the vibratory rate of a stressed animal.",
    source: "iCalmPet research"
  },
  {
    id: 6,
    year: 2020,
    researcher: "Abigail M Lindig et al.",
    institution: "National Institutes of Health",
    finding: "Exposure to classical music appears to have a calming influence on dogs in stressful environments, with no additional benefit observed from any music purposely designed for dogs.",
    source: "National Library of Medicine"
  },
  {
    id: 7,
    year: 2022,
    researcher: "Veterinary researchers",
    institution: "Multiple institutions",
    finding: "As pets listen to classical music, cortisol levels (the stress hormone) lower in the blood. This provides the calming effect that helps regulate emotion through the auditory cortex and multiple parts of the limbic system.",
    source: "Michelson Found Animals"
  }
];

// Benefits of music for pets
export const musicBenefits = [
  {
    id: 1,
    title: "Reduces Anxiety",
    description: "Scientific studies show that certain types of music can significantly reduce anxiety in pets, especially during stressful situations like thunderstorms, fireworks, or when left alone.",
    icon: "calm"
  },
  {
    id: 2,
    title: "Lowers Stress Hormones",
    description: "Research has demonstrated that calming music lowers cortisol levels (the stress hormone) in pets' bloodstream, creating a physiological calming effect.",
    icon: "heartbeat"
  },
  {
    id: 3,
    title: "Improves Sleep Quality",
    description: "Pets exposed to appropriate music spend more time sleeping and experience better quality rest, which is essential for their overall health and wellbeing.",
    icon: "sleep"
  },
  {
    id: 4,
    title: "Reduces Problem Behaviors",
    description: "Calming music has been shown to reduce unwanted behaviors like excessive barking, destructive chewing, and other anxiety-related issues in pets.",
    icon: "behavior"
  },
  {
    id: 5,
    title: "Creates a Comforting Environment",
    description: "The right music helps create a sense of security for pets, especially when they're in unfamiliar environments or when their owners are away.",
    icon: "home"
  },
  {
    id: 6,
    title: "Helps with Separation Anxiety",
    description: "Studies show that specially designed music can help pets cope with separation anxiety, making time alone less stressful for both pets and their owners.",
    icon: "heart"
  }
];

// Testimonials with more specific details
export const enhancedTestimonials = [
  {
    id: 1,
    name: "Sarah K.",
    petName: "Bella",
    petType: "Rescue Dog",
    quote: "My anxious rescue dog used to bark for hours when I left. After just 2 weeks of using Pawphonic, she settles down within minutes. Her cortisol levels dropped by 30% according to our vet, and she's finally able to relax when I'm gone. It's been life-changing for both of us!",
    image: "testimonial1"
  },
  {
    id: 2,
    name: "Michael T.",
    petName: "Max",
    petType: "Cat",
    quote: "I was skeptical at first, but the difference in my cat's behavior is remarkable. He used to hide during thunderstorms, but now with Pawphonic playing, he stays calm and even purrs through the loudest storms. His anxiety-related overgrooming has completely stopped.",
    image: "testimonial2"
  },
  {
    id: 3,
    name: "Dr. Sarah Chen",
    petName: "",
    petType: "Veterinarian",
    quote: "As a veterinarian with 15 years of experience, I've seen the effects of stress on pets firsthand. Pawphonic's science-backed approach aligns perfectly with research showing how specific sound frequencies can reduce anxiety. I've recommended it to over 200 clients with anxiety-prone pets.",
    image: "testimonial3"
  }
];
