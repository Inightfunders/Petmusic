import React from 'react';
import dogCatCuddling from '../assets/images/dog_cat_cuddling.jpeg';
import { scientificData, musicBenefits } from '../data/scientificData';

const WhyPetsNeedMusic: React.FC = () => {
  return (
    <section id="why-pets-need-music" className="py-16 bg-pawphonic-beige">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Backed by science. Loved by pets.</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Research shows that specially designed music can reduce anxiety by up to 30%, lower stress hormones, 
          and significantly improve your pet's wellbeing when you're away.
        </p>
        
        <div className="flex flex-col items-center md:flex-row md:justify-between">
          <div className="w-full mb-10 md:w-1/2 md:pr-10 md:mb-0" data-aos="fade-right" data-aos-delay="100">
            <div className="p-6 mb-6 bg-white rounded-lg shadow-md" data-aos="fade-up" data-aos-delay="150">
              <h3 className="mb-3 text-lg font-semibold text-pawphonic-blue">Research Highlights</h3>
              <ul className="space-y-3 text-sm text-gray-600">
                {scientificData.slice(0, 3).map(study => (
                  <li key={study.id} className="pl-4 border-l-2 border-pawphonic-blue">
                    <span className="font-semibold">{study.year}, {study.researcher}:</span> {study.finding}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              {musicBenefits.slice(0, 4).map(benefit => (
                <div key={benefit.id} className="p-6 transition-all bg-white rounded-xl hover:shadow-md" data-aos="zoom-in" data-aos-delay={150 + (benefit.id * 50)}>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center justify-center w-10 h-10 mr-3 rounded-full bg-pawphonic-blue">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold">{benefit.title}</h3>
                  </div>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="w-full md:w-1/2" data-aos="fade-left" data-aos-delay="200">
            <div className="relative overflow-hidden rounded-lg shadow-xl">
              <img 
                src={dogCatCuddling} 
                alt="Dog and cat cuddling while relaxing to music" 
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-pawphonic-blue/20 to-transparent"></div>
            </div>
            <div className="p-5 mt-6 bg-pawphonic-light-blue/20 rounded-lg" data-aos="fade-up" data-aos-delay="300">
              <p className="text-pawphonic-blue font-medium">
                <span className="font-bold">Did you know?</span> A 2022 study found that as pets listen to classical music, 
                cortisol levels (the stress hormone) lower in their bloodstream by up to 30%, creating a measurable calming effect 
                through the auditory cortex and limbic system.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyPetsNeedMusic;
