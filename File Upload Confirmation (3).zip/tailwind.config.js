/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        'pawphonic-blue': '#6BBBDB',
        'pawphonic-light-blue': '#A3D5E9',
        'pawphonic-beige': '#F5EFE0',
        'pawphonic-green': '#A3C9A8',
        'pawphonic-light-green': '#D1E8D5',
      },
      fontFamily: {
        'sans': ['Inter', 'Lato', 'Poppins', 'ui-sans-serif', 'system-ui'],
      },
    },
  },
  plugins: [],
}
