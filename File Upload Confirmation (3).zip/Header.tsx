import React, { useState } from 'react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="container py-4 mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-pawphonic-blue">Pawphonic</h1>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-600 rounded-md hover:text-pawphonic-blue focus:outline-none"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex md:items-center md:space-x-8">
            <a href="#why-pets-need-music" className="text-gray-600 hover:text-pawphonic-blue">Why Music?</a>
            <a href="#personalized" className="text-gray-600 hover:text-pawphonic-blue">Personalization</a>
            <a href="#soundscapes" className="text-gray-600 hover:text-pawphonic-blue">Soundscapes</a>
            <a href="#pricing" className="text-gray-600 hover:text-pawphonic-blue">Pricing</a>
            <a href="#demo" className="text-gray-600 hover:text-pawphonic-blue">Demo</a>
            <button className="btn-primary">Join Waitlist</button>
          </nav>
        </div>
        
        {/* Mobile navigation */}
        {isMenuOpen && (
          <nav className="flex flex-col mt-4 space-y-4 md:hidden">
            <a href="#why-pets-need-music" className="text-gray-600 hover:text-pawphonic-blue">Why Music?</a>
            <a href="#personalized" className="text-gray-600 hover:text-pawphonic-blue">Personalization</a>
            <a href="#soundscapes" className="text-gray-600 hover:text-pawphonic-blue">Soundscapes</a>
            <a href="#pricing" className="text-gray-600 hover:text-pawphonic-blue">Pricing</a>
            <a href="#demo" className="text-gray-600 hover:text-pawphonic-blue">Demo</a>
            <button className="btn-primary">Join Waitlist</button>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
