# Pawphonic Website Documentation

## Overview
This document provides information about the Pawphonic website, a personalized music service for pets. The website is built using React with TypeScript and Tailwind CSS, featuring responsive design, animations, and email waitlist functionality.

## Live Website
The website is deployed and accessible at: [https://histzxus.manus.space](https://histzxus.manus.space)

## Technology Stack
- React with TypeScript
- Tailwind CSS for styling
- AOS (Animate On Scroll) library for animations
- Mailchimp integration for email waitlist collection

## Features
- Responsive design that works on mobile, tablet, and desktop devices
- Email waitlist functionality with form validation and success/error handling
- Smooth scroll animations and transitions
- Interactive UI elements with hover effects
- Personalization quiz UI mockup
- Daily soundscapes timeline visualization
- Subscription details section
- Demo video preview with testimonials
- Footer with social links

## Project Structure
- `/src/components/`: Contains all React components
- `/src/services/`: Contains service integrations (Mailchimp)
- `/src/hooks/`: Contains custom React hooks (animations)
- `/src/assets/`: Contains images and other static assets

## Maintenance
To update or modify the website:
1. Clone the repository
2. Install dependencies with `npm install`
3. Make changes to the source code
4. Test locally with `npm start`
5. Build for production with `npm run build`
6. Deploy the updated build folder

## Mailchimp Integration
The website includes a simplified Mailchimp integration for demonstration purposes. To connect to a real Mailchimp account:
1. Sign up for a Mailchimp account
2. Create an API key and list ID
3. Update the configuration in `/src/services/mailchimp.ts`

## Contact
For any questions or support, please contact the developer.
