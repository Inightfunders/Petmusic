// src/services/stripe.ts
import { loadStripe } from '@stripe/stripe-js';

// Replace with your actual Stripe publishable key
// In a production environment, this should be stored in an environment variable
const stripePromise = loadStripe('pk_test_TYooMQauvdEDq54NiTphI7jx');

export interface PriceOption {
  id: string;
  name: string;
  description: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
}

export const priceOptions: PriceOption[] = [
  {
    id: 'price_monthly_basic',
    name: 'Basic',
    description: 'Perfect for one pet',
    price: 9.99,
    interval: 'month',
    features: [
      'Daily personalized music',
      'Basic mood adaptation',
      'Email delivery',
      'Up to 1 pet profile'
    ]
  },
  {
    id: 'price_monthly_premium',
    name: 'Premium',
    description: 'Ideal for multiple pets',
    price: 19.99,
    interval: 'month',
    features: [
      'Daily personalized music',
      'Advanced mood adaptation',
      'Email delivery',
      'Up to 3 pet profiles',
      'Priority support'
    ]
  },
  {
    id: 'price_yearly_basic',
    name: 'Basic Annual',
    description: 'Save 16% with annual billing',
    price: 99.99,
    interval: 'year',
    features: [
      'Daily personalized music',
      'Basic mood adaptation',
      'Email delivery',
      'Up to 1 pet profile',
      '2 months free'
    ]
  },
  {
    id: 'price_yearly_premium',
    name: 'Premium Annual',
    description: 'Best value for multiple pets',
    price: 199.99,
    interval: 'year',
    features: [
      'Daily personalized music',
      'Advanced mood adaptation',
      'Email delivery',
      'Up to 3 pet profiles',
      'Priority support',
      '2 months free'
    ]
  }
];

// Function to create a Stripe Checkout Session
export const createCheckoutSession = async (priceId: string, customerEmail?: string) => {
  try {
    // In a real implementation, this would be a call to your backend
    // which would create a Checkout Session and return the session ID
    
    // For demo purposes, we'll simulate a successful response
    // In production, you would make an API call to your server:
    // const response = await fetch('/api/create-checkout-session', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ priceId, customerEmail })
    // });
    // const session = await response.json();
    
    // Simulate a successful response with a mock session ID
    const mockSessionId = `cs_test_${Math.random().toString(36).substring(2, 15)}`;
    
    // Load Stripe.js
    const stripe = await stripePromise;
    
    if (!stripe) {
      throw new Error('Stripe failed to load');
    }
    
    // Redirect to Checkout
    // In a real implementation, this would use the actual session ID from your backend
    // const { error } = await stripe.redirectToCheckout({
    //   sessionId: mockSessionId,
    // });
    
    // if (error) {
    //   throw new Error(error.message);
    // }
    
    // For demo purposes, we'll simulate a successful checkout
    // and redirect to the payment success page
    window.location.href = '/payment-success';
    
    return { success: true };
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return { success: false, error };
  }
};

export default stripePromise;
