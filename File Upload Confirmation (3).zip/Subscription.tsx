import React, { useState } from 'react';
import { priceOptions, createCheckoutSession, PriceOption } from '../services/stripe';

const Subscription: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<string>('price_monthly_premium');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const handleSubscribe = async (priceId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      if (!email) {
        throw new Error('Please enter your email address');
      }
      
      const result = await createCheckoutSession(priceId, email);
      
      if (!result.success) {
        throw new Error('Failed to create checkout session');
      }
      
      // In a real implementation, the redirect would happen in the createCheckoutSession function
      // For demo purposes, we'll simulate a redirect to the questionnaire page
      window.location.href = '/questionnaire';
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="subscription" className="py-16 bg-white">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Choose your subscription plan</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Select the perfect plan for your pet's musical journey. Cancel anytime.
        </p>
        
        <div className="flex justify-center mb-8">
          <div className="p-2 bg-pawphonic-beige rounded-lg">
            <button 
              className={`px-4 py-2 rounded-lg transition-all ${selectedPlan.includes('monthly') ? 'bg-white shadow-md' : 'hover:bg-white/50'}`}
              onClick={() => setSelectedPlan(selectedPlan.replace('yearly', 'monthly'))}
            >
              Monthly
            </button>
            <button 
              className={`px-4 py-2 rounded-lg transition-all ${selectedPlan.includes('yearly') ? 'bg-white shadow-md' : 'hover:bg-white/50'}`}
              onClick={() => setSelectedPlan(selectedPlan.replace('monthly', 'yearly'))}
            >
              Yearly <span className="text-xs text-pawphonic-blue font-semibold">Save 16%</span>
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2 max-w-5xl mx-auto">
          {priceOptions
            .filter(plan => plan.id.includes(selectedPlan.includes('monthly') ? 'monthly' : 'yearly'))
            .map((plan: PriceOption) => (
              <div 
                key={plan.id} 
                className={`p-6 rounded-xl shadow-custom transition-all hover:shadow-lg ${plan.id === selectedPlan ? 'border-2 border-pawphonic-blue' : 'border border-gray-200'}`}
                data-aos="fade-up"
                data-aos-delay={plan.name === 'Basic' ? '150' : '250'}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-pawphonic-blue">{plan.name}</h3>
                    <p className="text-gray-600">{plan.description}</p>
                  </div>
                  {plan.id === selectedPlan && (
                    <span className="px-3 py-1 text-xs font-semibold text-white bg-pawphonic-blue rounded-full">Selected</span>
                  )}
                </div>
                
                <div className="mb-6">
                  <span className="text-3xl font-bold">${plan.price}</span>
                  <span className="text-gray-600">/{plan.interval}</span>
                </div>
                
                <ul className="mb-8 space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <svg className="w-5 h-5 mr-2 text-pawphonic-blue" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                      </svg>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mb-4">
                  <input
                    type="email"
                    placeholder="Your email address"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                
                <button 
                  className={`w-full py-3 font-medium text-white transition-all rounded-lg ${plan.id === selectedPlan ? 'bg-pawphonic-blue hover:bg-pawphonic-blue-dark' : 'bg-gray-400 hover:bg-gray-500'}`}
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={isLoading}
                >
                  {isLoading ? 'Processing...' : `Subscribe Now`}
                </button>
                
                {plan.id === selectedPlan && error && (
                  <p className="mt-2 text-sm text-red-600">{error}</p>
                )}
                
                <p className="mt-4 text-xs text-center text-gray-500">
                  Secure payment powered by Stripe. Cancel anytime.
                </p>
              </div>
            ))}
        </div>
        
        <div className="mt-12 p-6 bg-pawphonic-beige rounded-lg max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="300">
          <h3 className="text-xl font-semibold text-pawphonic-blue mb-3">What happens after you subscribe?</h3>
          <ol className="space-y-3 ml-6 list-decimal">
            <li>You'll complete a detailed questionnaire about your pet's personality, preferences, and needs</li>
            <li>Our team of pet music specialists will create custom compositions for your pet</li>
            <li>Within 3 weeks, you'll receive your first personalized music tracks via email</li>
            <li>You'll continue to receive new, adapted compositions based on your feedback</li>
          </ol>
          <p className="mt-4 text-sm text-pawphonic-blue font-medium">
            Each composition is scientifically designed to address your pet's specific needs and behaviors.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Subscription;
