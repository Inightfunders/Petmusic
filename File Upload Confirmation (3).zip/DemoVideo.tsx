import React from 'react';
import { enhancedTestimonials } from '../data/scientificData';
import catSleepingFireplace from '../assets/images/cat_sleeping_fireplace.jpeg';

const DemoVideo: React.FC = () => {
  return (
    <section id="demo" className="py-16 bg-white">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">See the science in action.</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Watch how our scientifically composed music transforms anxious pets into relaxed companions—even when you're not home.
        </p>
        
        <div className="max-w-4xl mx-auto mt-12" data-aos="zoom-in" data-aos-delay="150">
          <div className="relative overflow-hidden bg-black rounded-lg shadow-xl aspect-video">
            <img 
              src={catSleepingFireplace} 
              alt="Cat sleeping peacefully by fireplace while listening to music" 
              className="object-cover w-full h-full opacity-80"
            />
            
            {/* Play button overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex items-center justify-center w-20 h-20 transition-transform duration-300 bg-white rounded-full cursor-pointer hover:scale-110" data-aos="zoom-in" data-aos-delay="300">
                <svg className="w-10 h-10 text-pawphonic-blue" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd"></path>
                </svg>
              </div>
            </div>
            
            <div className="absolute bottom-0 left-0 right-0 p-6 text-white bg-gradient-to-t from-black/80 to-transparent">
              <h3 className="text-2xl font-bold">The Pawphonic Effect</h3>
              <p className="mt-2">See how our specialized frequencies reduce anxiety in real pets</p>
            </div>
          </div>
          
          <div className="mt-12">
            <h3 className="mb-6 text-2xl font-bold text-center text-pawphonic-blue" data-aos="fade-up" data-aos-delay="200">
              Real Results from Real Pet Parents
            </h3>
            
            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              {enhancedTestimonials.map((testimonial, index) => (
                <div key={testimonial.id} className="p-6 bg-pawphonic-beige rounded-xl" data-aos="fade-up" data-aos-delay={250 + (index * 50)}>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center justify-center w-10 h-10 mr-3 rounded-full bg-pawphonic-blue">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{testimonial.name}</h3>
                      <p className="text-sm text-gray-600">{testimonial.petType}</p>
                    </div>
                  </div>
                  <p className="text-gray-700">
                    "{testimonial.quote}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoVideo;
