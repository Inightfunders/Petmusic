import React, { useState } from 'react';

interface EmailDeliveryProps {
  email?: string;
}

const EmailDeliverySubscription: React.FC<EmailDeliveryProps> = ({ email = '' }) => {
  const [emailAddress, setEmailAddress] = useState<string>(email);
  const [frequency, setFrequency] = useState<string>('daily');
  const [preferredTime, setPreferredTime] = useState<string>('morning');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    try {
      // Validate email
      if (!emailAddress || !/^\S+@\S+\.\S+$/.test(emailAddress)) {
        throw new Error('Please enter a valid email address');
      }
      
      // In a real implementation, this would send the data to your backend
      // For demo purposes, we'll simulate a successful submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate successful subscription
      setIsSuccess(true);
      
      // In production, this would be an API call:
      // const response = await fetch('/api/subscribe-email-delivery', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ email: emailAddress, frequency, preferredTime })
      // });
      // if (!response.ok) throw new Error('Failed to subscribe');
      // const data = await response.json();
      
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="email-delivery" className="py-16 bg-pawphonic-beige">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Email Delivery Preferences</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Customize how you'd like to receive your pet's personalized music tracks.
        </p>
        
        <div className="max-w-2xl mx-auto">
          {isSuccess ? (
            <div className="p-8 bg-white rounded-xl shadow-custom text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-pawphonic-green">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              
              <h3 className="text-2xl font-bold text-pawphonic-blue mb-4">Email Delivery Set!</h3>
              <p className="text-lg mb-6">
                Your personalized pet music will be delivered to <strong>{emailAddress}</strong> {frequency}, 
                during the <strong>{preferredTime}</strong>.
              </p>
              
              <p className="text-gray-600 mb-8">
                Your first delivery will arrive within 3 weeks after our team creates your pet's custom music.
                You can change your delivery preferences at any time from your account settings.
              </p>
              
              <button 
                onClick={() => setIsSuccess(false)}
                className="px-6 py-2 text-pawphonic-blue border border-pawphonic-blue rounded-lg hover:bg-pawphonic-blue/10"
              >
                Edit Preferences
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-8 bg-white rounded-xl shadow-custom">
              <div className="space-y-6">
                <div>
                  <label htmlFor="email" className="block font-medium mb-2">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
                    placeholder="Where we'll send your pet's music"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="frequency" className="block font-medium mb-2">
                    Delivery Frequency
                  </label>
                  <select
                    id="frequency"
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="biweekly">Bi-weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                  <p className="mt-1 text-sm text-gray-500">
                    How often you'd like to receive new music for your pet
                  </p>
                </div>
                
                <div>
                  <label htmlFor="preferredTime" className="block font-medium mb-2">
                    Preferred Time of Day
                  </label>
                  <select
                    id="preferredTime"
                    value={preferredTime}
                    onChange={(e) => setPreferredTime(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
                  >
                    <option value="morning">Morning (6am - 10am)</option>
                    <option value="midday">Midday (10am - 2pm)</option>
                    <option value="afternoon">Afternoon (2pm - 6pm)</option>
                    <option value="evening">Evening (6pm - 10pm)</option>
                  </select>
                  <p className="mt-1 text-sm text-gray-500">
                    When you'd prefer to receive your pet's music
                  </p>
                </div>
              </div>
              
              {error && (
                <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-lg">
                  {error}
                </div>
              )}
              
              <div className="mt-8">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 font-medium text-white transition-all rounded-lg bg-pawphonic-blue hover:bg-pawphonic-blue-dark disabled:bg-gray-400"
                >
                  {isSubmitting ? 'Saving Preferences...' : 'Save Delivery Preferences'}
                </button>
              </div>
            </form>
          )}
          
          <div className="mt-8 p-6 bg-white rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold text-pawphonic-blue mb-3">How Email Delivery Works</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-pawphonic-blue flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                </svg>
                <span>Your pet's custom music will be delivered directly to your email inbox</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-pawphonic-blue flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                </svg>
                <span>Each delivery includes MP3 files that you can download and play for your pet</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-pawphonic-blue flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                </svg>
                <span>Music is composed based on your pet's profile and updated regularly based on your feedback</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-pawphonic-blue flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                </svg>
                <span>You can change your delivery preferences or pause deliveries at any time</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EmailDeliverySubscription;
