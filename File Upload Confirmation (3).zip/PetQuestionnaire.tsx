import React, { useState } from 'react';

interface Question {
  id: string;
  text: string;
  type: 'radio' | 'checkbox' | 'text' | 'select';
  options?: string[];
  required: boolean;
}

const PetQuestionnaire: React.FC = () => {
  const [step, setStep] = useState<number>(1);
  const [formData, setFormData] = useState({
    petName: '',
    petType: '',
    petAge: '',
    petBreed: '',
    anxietyLevel: '',
    separationAnxiety: false,
    noisePhobias: false,
    sleepIssues: false,
    energyLevel: '',
    musicPreference: [],
    additionalInfo: '',
    ownerName: '',
    ownerEmail: '',
  });
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isComplete, setIsComplete] = useState<boolean>(false);

  const questions: Record<number, Question[]> = {
    1: [
      {
        id: 'petName',
        text: 'What is your pet\'s name?',
        type: 'text',
        required: true,
      },
      {
        id: 'petType',
        text: 'What type of pet do you have?',
        type: 'radio',
        options: ['Dog', 'Cat', 'Bird', 'Other'],
        required: true,
      },
      {
        id: 'petAge',
        text: 'How old is your pet?',
        type: 'select',
        options: ['Less than 1 year', '1-3 years', '4-7 years', '8-12 years', '13+ years'],
        required: true,
      },
      {
        id: 'petBreed',
        text: 'What breed is your pet? (if applicable)',
        type: 'text',
        required: false,
      },
    ],
    2: [
      {
        id: 'anxietyLevel',
        text: 'How would you rate your pet\'s overall anxiety level?',
        type: 'radio',
        options: ['Very Low', 'Low', 'Moderate', 'High', 'Very High'],
        required: true,
      },
      {
        id: 'separationAnxiety',
        text: 'Does your pet experience separation anxiety when left alone?',
        type: 'radio',
        options: ['Yes', 'No', 'Sometimes'],
        required: true,
      },
      {
        id: 'noisePhobias',
        text: 'Does your pet have any noise phobias? (Check all that apply)',
        type: 'checkbox',
        options: ['Thunderstorms', 'Fireworks', 'Vacuum Cleaners', 'Traffic Noise', 'Other Loud Noises', 'None'],
        required: false,
      },
      {
        id: 'sleepIssues',
        text: 'Does your pet have trouble sleeping or relaxing?',
        type: 'radio',
        options: ['Yes', 'No', 'Sometimes'],
        required: true,
      },
    ],
    3: [
      {
        id: 'energyLevel',
        text: 'How would you describe your pet\'s energy level?',
        type: 'radio',
        options: ['Very Low', 'Low', 'Moderate', 'High', 'Very High'],
        required: true,
      },
      {
        id: 'musicPreference',
        text: 'Have you noticed your pet responding positively to any of these music types? (Check all that apply)',
        type: 'checkbox',
        options: ['Classical', 'Soft Rock', 'Reggae', 'Jazz', 'Nature Sounds', 'Piano Music', 'Not Sure'],
        required: false,
      },
      {
        id: 'additionalInfo',
        text: 'Is there anything else we should know about your pet to help create their perfect music?',
        type: 'text',
        required: false,
      },
    ],
    4: [
      {
        id: 'ownerName',
        text: 'Your name',
        type: 'text',
        required: true,
      },
      {
        id: 'ownerEmail',
        text: 'Your email address (where we\'ll send your pet\'s music)',
        type: 'text',
        required: true,
      },
    ],
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === 'checkbox') {
      const isChecked = (e.target as HTMLInputElement).checked;
      const option = value;
      
      setFormData(prev => {
        const field = name as keyof typeof prev;
        const currentValue = prev[field] as string[];
        
        if (isChecked) {
          return { ...prev, [field]: [...currentValue, option] };
        } else {
          return { ...prev, [field]: currentValue.filter(item => item !== option) };
        }
      });
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleNextStep = () => {
    // Validate current step
    const currentQuestions = questions[step];
    const isValid = currentQuestions.every(q => {
      if (!q.required) return true;
      const value = formData[q.id as keyof typeof formData];
      return value !== '' && value !== undefined && (Array.isArray(value) ? value.length > 0 : true);
    });

    if (!isValid) {
      alert('Please fill out all required fields before proceeding.');
      return;
    }

    if (step < Object.keys(questions).length) {
      setStep(step + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // In a real implementation, this would send the data to your backend
      // For demo purposes, we'll simulate a successful submission
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setIsComplete(true);
    } catch (error) {
      console.error('Error submitting questionnaire:', error);
      alert('There was an error submitting your questionnaire. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderQuestion = (question: Question) => {
    switch (question.type) {
      case 'text':
        return (
          <input
            type="text"
            id={question.id}
            name={question.id}
            value={formData[question.id as keyof typeof formData] as string}
            onChange={handleInputChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
            required={question.required}
          />
        );
      
      case 'select':
        return (
          <select
            id={question.id}
            name={question.id}
            value={formData[question.id as keyof typeof formData] as string}
            onChange={handleInputChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawphonic-blue"
            required={question.required}
          >
            <option value="">Select an option</option>
            {question.options?.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );
      
      case 'radio':
        return (
          <div className="space-y-2">
            {question.options?.map(option => (
              <label key={option} className="flex items-center space-x-2">
                <input
                  type="radio"
                  name={question.id}
                  value={option}
                  checked={formData[question.id as keyof typeof formData] === option}
                  onChange={handleInputChange}
                  className="w-4 h-4 text-pawphonic-blue"
                  required={question.required}
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        );
      
      case 'checkbox':
        return (
          <div className="space-y-2">
            {question.options?.map(option => (
              <label key={option} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name={question.id}
                  value={option}
                  checked={(formData[question.id as keyof typeof formData] as string[])?.includes(option)}
                  onChange={handleInputChange}
                  className="w-4 h-4 text-pawphonic-blue"
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        );
      
      default:
        return null;
    }
  };

  if (isComplete) {
    return (
      <section className="py-16 bg-pawphonic-beige min-h-screen">
        <div className="container px-4 mx-auto">
          <div className="max-w-2xl mx-auto p-8 bg-white rounded-xl shadow-custom">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-pawphonic-blue">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              
              <h2 className="text-3xl font-bold text-pawphonic-blue mb-4">Thank You!</h2>
              <p className="text-xl mb-6">Your pet questionnaire has been submitted successfully.</p>
              
              <div className="p-6 bg-pawphonic-beige rounded-lg mb-8">
                <h3 className="text-xl font-semibold text-pawphonic-blue mb-3">What happens next?</h3>
                <ol className="text-left space-y-3 ml-6 list-decimal">
                  <li>Our team of pet music specialists will review your questionnaire</li>
                  <li>We'll create custom compositions tailored specifically to {formData.petName}'s needs</li>
                  <li>Within 3 weeks, you'll receive your first personalized music tracks via email at {formData.ownerEmail}</li>
                  <li>You'll continue to receive new, adapted compositions based on your feedback</li>
                </ol>
              </div>
              
              <p className="text-gray-600 mb-8">
                If you have any questions in the meantime, please contact our support team at support@pawphonic.com
              </p>
              
              <a 
                href="/"
                className="px-8 py-3 text-lg font-medium text-white transition-all rounded-lg bg-pawphonic-blue hover:bg-pawphonic-blue-dark"
              >
                Return to Homepage
              </a>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-pawphonic-beige min-h-screen">
      <div className="container px-4 mx-auto">
        <h2 className="section-title" data-aos="fade-up">Tell us about your pet</h2>
        <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
          Help us create the perfect personalized music experience for your furry friend.
        </p>
        
        <div className="max-w-2xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {Array.from({ length: Object.keys(questions).length }).map((_, i) => (
                <div 
                  key={i} 
                  className={`flex items-center justify-center w-10 h-10 rounded-full ${
                    i + 1 === step ? 'bg-pawphonic-blue text-white' : 
                    i + 1 < step ? 'bg-pawphonic-green text-white' : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {i + 1 < step ? (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  ) : (
                    i + 1
                  )}
                </div>
              ))}
            </div>
            <div className="relative mt-2">
              <div className="absolute inset-0 flex items-center" aria-hidden="true">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-between">
                {Array.from({ length: Object.keys(questions).length }).map((_, i) => (
                  <div 
                    key={i}
                    className={`text-sm ${
                      i + 1 === step ? 'text-pawphonic-blue font-medium' : 
                      i + 1 < step ? 'text-pawphonic-green' : 'text-gray-500'
                    }`}
                  >
                    {i === 0 ? 'Basic Info' : 
                     i === 1 ? 'Behavior' : 
                     i === 2 ? 'Preferences' : 'Contact'}
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="p-8 bg-white rounded-xl shadow-custom">
            <h3 className="text-xl font-semibold text-pawphonic-blue mb-6">
              {step === 1 ? 'Basic Information' : 
               step === 2 ? 'Behavior & Anxiety' : 
               step === 3 ? 'Preferences & Personality' : 'Contact Information'}
            </h3>
            
            <div className="space-y-6">
              {questions[step].map(question => (
                <div key={question.id} className="space-y-2">
                  <label htmlFor={question.id} className="block font-medium">
                    {question.text} {question.required && <span className="text-red-500">*</span>}
                  </label>
                  {renderQuestion(question)}
                </div>
              ))}
            </div>
            
            <div className="flex justify-between mt-8">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="px-6 py-2 border border-pawphonic-blue text-pawphonic-blue rounded-lg hover:bg-pawphonic-blue/10"
                >
                  Previous
                </button>
              ) : (
                <div></div>
              )}
              
              {step < Object.keys(questions).length ? (
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-6 py-2 bg-pawphonic-blue text-white rounded-lg hover:bg-pawphonic-blue-dark"
                >
                  Next
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-pawphonic-blue text-white rounded-lg hover:bg-pawphonic-blue-dark disabled:bg-gray-400"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit'}
                </button>
              )}
            </div>
          </form>
          
          <div className="mt-8 p-6 bg-white rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold text-pawphonic-blue mb-3">What happens after you submit?</h3>
            <p className="text-gray-600">
              Our team will carefully review your responses and create custom music compositions 
              specifically designed for your pet's unique personality and needs. You'll receive 
              your first personalized tracks within 3 weeks via email.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PetQuestionnaire;
